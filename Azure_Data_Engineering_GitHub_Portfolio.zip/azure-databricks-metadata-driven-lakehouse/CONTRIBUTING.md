# Contributing

Thanks for improving this portfolio project.

1. Create a feature branch from `main`.
2. Keep changes focused and document any architectural decisions.
3. Never add secrets, production data, or unredacted logs.
4. Run the checks in the README before opening a pull request.
5. State which parts are tested locally, tested in Azure, or still examples.
6. For Azure changes, include sanitized validation evidence and explain any assumptions about AdventureWorks version, runtime, or schema.

## Suggested branch naming

- `feature/metadata-driven-copy`
- `feature/silver-data-quality`
- `fix/incremental-watermark`
- `docs/architecture-update`
