-- SQL Server control database. Starter DDL; validate before use.
IF OBJECT_ID('dbo.source_config','U') IS NULL
CREATE TABLE dbo.source_config (
 source_id INT NOT NULL PRIMARY KEY,
 source_name VARCHAR(100) NOT NULL,
 source_type VARCHAR(50) NOT NULL,
 connection_ref VARCHAR(200) NOT NULL, -- linked-service reference only; no secret
 database_name VARCHAR(128) NOT NULL,
 is_active BIT NOT NULL CONSTRAINT DF_source_active DEFAULT(1)
);
GO
IF OBJECT_ID('dbo.table_config','U') IS NULL
CREATE TABLE dbo.table_config (
 table_id INT NOT NULL PRIMARY KEY,
 source_id INT NOT NULL REFERENCES dbo.source_config(source_id),
 schema_name VARCHAR(128) NOT NULL,
 table_name VARCHAR(128) NOT NULL,
 load_type VARCHAR(20) NOT NULL CHECK(load_type IN ('FULL','INCREMENTAL')),
 watermark_column VARCHAR(128) NULL,
 last_successful_watermark VARCHAR(100) NULL,
 target_layer VARCHAR(20) NOT NULL DEFAULT('BRONZE') CHECK(target_layer IN ('BRONZE')),
 is_active BIT NOT NULL CONSTRAINT DF_table_active DEFAULT(1)
);
GO
IF OBJECT_ID('dbo.pipeline_run_log','U') IS NULL
CREATE TABLE dbo.pipeline_run_log (
 run_log_id BIGINT IDENTITY(1,1) PRIMARY KEY,
 run_id VARCHAR(100) NOT NULL,
 pipeline_name VARCHAR(200) NULL,
 table_id INT NULL,
 schema_name VARCHAR(128) NULL,
 table_name VARCHAR(128) NULL,
 start_time_utc DATETIME2(3) NULL,
 end_time_utc DATETIME2(3) NULL,
 status VARCHAR(20) NOT NULL,
 rows_read BIGINT NULL,
 rows_written BIGINT NULL,
 watermark_value VARCHAR(100) NULL,
 error_message NVARCHAR(2000) NULL,
 created_utc DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
GO
CREATE INDEX IX_table_config_active ON dbo.table_config(is_active, source_id);
CREATE INDEX IX_run_log_run ON dbo.pipeline_run_log(run_id, table_id);
GO
