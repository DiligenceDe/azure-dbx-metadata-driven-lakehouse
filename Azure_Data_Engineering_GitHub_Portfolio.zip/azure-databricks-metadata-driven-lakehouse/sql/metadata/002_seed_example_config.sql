-- EXAMPLE ONLY. Verify names against your AdventureWorks version.
IF NOT EXISTS (SELECT 1 FROM dbo.source_config WHERE source_id=1)
 INSERT dbo.source_config(source_id,source_name,source_type,connection_ref,database_name,is_active)
 VALUES (1,'AdventureWorks SQL Server','SQLServer','ls_sqlserver_adventureworks','AdventureWorks2022',1);
GO
DECLARE @t TABLE(table_id INT, schema_name VARCHAR(128), table_name VARCHAR(128));
INSERT @t VALUES
 (1,'Sales','Customer'),
 (2,'Sales','SalesOrderHeader'),
 (3,'Sales','SalesOrderDetail'),
 (4,'Production','Product'),
 (5,'Person','Person');
MERGE dbo.table_config AS d
USING @t AS s ON d.table_id=s.table_id
WHEN MATCHED THEN UPDATE SET d.source_id=1,d.schema_name=s.schema_name,d.table_name=s.table_name,
 d.load_type='FULL',d.watermark_column=NULL,d.target_layer='BRONZE',d.is_active=1
WHEN NOT MATCHED THEN INSERT(table_id,source_id,schema_name,table_name,load_type,watermark_column,
 last_successful_watermark,target_layer,is_active)
 VALUES(s.table_id,1,s.schema_name,s.table_name,'FULL',NULL,NULL,'BRONZE',1);
GO
-- AdventureWorks editions differ. Confirm Sales.Customer and Person.Person columns.
