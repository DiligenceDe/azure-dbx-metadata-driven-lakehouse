"""Lightweight checks for sanitized example configuration files."""
import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CONFIG_DIR = ROOT / "config"


class ConfigExampleTests(unittest.TestCase):
    def test_example_json_files_are_valid(self):
        files = list(CONFIG_DIR.glob("*.json"))
        self.assertTrue(files, "Expected at least one example JSON configuration file")
        for path in files:
            with self.subTest(path=path.name):
                json.loads(path.read_text(encoding="utf-8"))

    def test_config_files_are_examples_not_real_secret_store(self):
        for path in CONFIG_DIR.glob("*.json"):
            content = path.read_text(encoding="utf-8").lower()
            for forbidden in ("password=", "accountkey=", "client_secret"):
                self.assertNotIn(forbidden, content, f"Potential secret-like content in {path.name}")


if __name__ == "__main__":
    unittest.main()
