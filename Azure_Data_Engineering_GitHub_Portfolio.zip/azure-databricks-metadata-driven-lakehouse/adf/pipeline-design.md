# ADF Pipeline Design

This is a build guide, not an exported ADF template. Create and test activities in your ADF instance.

## Lookup query
```sql
SELECT s.source_id, s.source_name, s.connection_ref, s.database_name,
       t.table_id, t.schema_name, t.table_name, t.load_type,
       t.watermark_column, t.last_successful_watermark, t.target_layer
FROM dbo.source_config s
JOIN dbo.table_config t ON t.source_id = s.source_id
WHERE s.is_active = 1 AND t.is_active = 1;
```
Set Lookup `firstRowOnly = false`. ForEach items:
`@activity('Lookup_ActiveTables').output.value`

## Item expressions
- Schema: `@item().schema_name`
- Table: `@item().table_name`
- Run ID: `@pipeline().RunId`

## Landing path pattern
```text
@concat('AdventureWorks/', item().schema_name, '/', item().table_name,
        '/run_id=', pipeline().RunId)
```
Use a parameterized ADLS Gen2 dataset with Parquet format. Confirm whether folder path and file name are separate dataset parameters in your chosen connector.

## Full/incremental loads
Start with full loads. Add incremental source queries only after handling null initial watermarks, data types, quoting, late-arriving updates, and safe watermark advancement. Validate identifiers from metadata and never concatenate untrusted values directly into SQL. Consider a stored procedure or source-side view for complex predicates.

## Logging
Use success/failure dependency paths to log run ID, table, start/end, status, row counts, watermark, and sanitized error message. Retry transient errors only.
