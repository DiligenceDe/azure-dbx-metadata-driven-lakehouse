# Databricks notebook source - starter; adapt paths and access controls.
from pyspark.sql import functions as F

for n in ["landing_path","target_path","schema_name","table_name","run_id"]:
    dbutils.widgets.text(n, "")
p = {n: dbutils.widgets.get(n) for n in ["landing_path","target_path","schema_name","table_name","run_id"]}
if any(not p[n] for n in ["landing_path","target_path","schema_name","table_name"]):
    raise ValueError("landing_path, target_path, schema_name, table_name are required")

df = spark.read.parquet(p["landing_path"])
bronze = (df.withColumn("_ingested_at_utc", F.current_timestamp())
            .withColumn("_source_schema", F.lit(p["schema_name"]))
            .withColumn("_source_table", F.lit(p["table_name"]))
            .withColumn("_pipeline_run_id", F.lit(p["run_id"])))
# IMPORTANT: append is suitable only when each run contains new records.
# For full-load reruns, use controlled overwrite or Delta MERGE to avoid duplicates.
(bronze.write.format("delta").mode("append").option("mergeSchema","true").save(p["target_path"]))
print(f"Bronze write complete: {p['schema_name']}.{p['table_name']}")
