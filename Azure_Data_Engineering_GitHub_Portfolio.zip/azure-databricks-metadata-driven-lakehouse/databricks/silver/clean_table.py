# Databricks notebook source - generic starter; configure required fields per table.
from pyspark.sql import functions as F, Window
import re

for n in ["bronze_path","silver_path","key_columns"]:
    dbutils.widgets.text(n, "")
bronze_path = dbutils.widgets.get("bronze_path")
silver_path = dbutils.widgets.get("silver_path")
keys = [x.strip() for x in dbutils.widgets.get("key_columns").split(",") if x.strip()]
if not bronze_path or not silver_path:
    raise ValueError("bronze_path and silver_path are required")

df = spark.read.format("delta").load(bronze_path)
for old in df.columns:
    new = re.sub(r"[^a-zA-Z0-9]+","_",old.strip()).strip("_").lower()
    if old != new:
        df = df.withColumnRenamed(old,new)
df = df.withColumn("_dq_required_fields_pass", F.lit(True))  # Replace with real rules.
if keys:
    missing = [k for k in keys if k not in df.columns]
    if missing:
        raise ValueError(f"Missing configured key columns: {missing}")
    if "_ingested_at_utc" in df.columns:
        w = Window.partitionBy(*keys).orderBy(F.col("_ingested_at_utc").desc_nulls_last())
        df = df.withColumn("_rn",F.row_number().over(w)).filter(F.col("_rn")==1).drop("_rn")
(df.write.format("delta").mode("overwrite").option("overwriteSchema","true").save(silver_path))
print(f"Silver write complete; rows={df.count()}")
