# Databricks notebook source - illustrative Gold model; validate columns for your sample DB.
from pyspark.sql import functions as F
names = ["customer_silver_path","person_silver_path","product_silver_path","order_header_silver_path","order_detail_silver_path","gold_root"]
for n in names: dbutils.widgets.text(n,"")
p = {n:dbutils.widgets.get(n) for n in names}
if any(not v for v in p.values()): raise ValueError("All input paths and gold_root are required")
customer = spark.read.format("delta").load(p["customer_silver_path"])
person = spark.read.format("delta").load(p["person_silver_path"])
product = spark.read.format("delta").load(p["product_silver_path"])
header = spark.read.format("delta").load(p["order_header_silver_path"])
detail = spark.read.format("delta").load(p["order_detail_silver_path"])

# Expected normalized columns must be checked against your AdventureWorks edition.
dim_customer = (customer.alias("c").join(person.alias("p"),
    F.col("c.personid")==F.col("p.businessentityid"),"left")
    .select(F.col("c.customerid").alias("customer_id"),
            F.col("p.firstname").alias("first_name"),
            F.col("p.lastname").alias("last_name"),
            F.current_timestamp().alias("_built_at_utc")))
dim_product = product.select(F.col("productid").alias("product_id"),
    F.col("name").alias("product_name"), F.col("productnumber").alias("product_number"),
    F.col("color").alias("color"), F.current_timestamp().alias("_built_at_utc"))
fact_sales = (detail.alias("d").join(header.alias("h"),
    F.col("d.salesorderid")==F.col("h.salesorderid"),"inner")
    .select(F.col("h.salesorderid").alias("sales_order_id"),
      F.col("d.salesorderdetailid").alias("sales_order_detail_id"),
      F.col("h.customerid").alias("customer_id"), F.col("d.productid").alias("product_id"),
      F.col("h.orderdate").alias("order_date"), F.col("d.orderqty").alias("order_quantity"),
      F.col("d.unitprice").alias("unit_price"),
      (F.col("d.orderqty").cast("decimal(18,2)")*F.col("d.unitprice").cast("decimal(18,2)")).alias("gross_line_amount"),
      F.current_timestamp().alias("_built_at_utc")))
for name, frame in [("dim_customer",dim_customer),("dim_product",dim_product),("fact_sales",fact_sales)]:
    frame.write.format("delta").mode("overwrite").option("overwriteSchema","true").save(p["gold_root"].rstrip("/")+"/"+name)
print("Gold writes complete: dim_customer, dim_product, fact_sales")
