"""Reusable lightweight data-quality helpers."""
from pyspark.sql import DataFrame, functions as F

def required_columns_present(df: DataFrame, required_columns: list[str]) -> bool:
    return set(required_columns).issubset(set(df.columns))

def null_count(df: DataFrame, column_name: str) -> int:
    return df.filter(F.col(column_name).isNull()).count()

def duplicate_key_group_count(df: DataFrame, key_columns: list[str]) -> int:
    return df.groupBy(*key_columns).count().filter(F.col("count") > 1).count()
