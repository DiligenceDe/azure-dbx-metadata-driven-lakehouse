# Publish this project to GitHub

This guide publishes the local folder as a GitHub repository. It does not create a repository in your GitHub account automatically; you must sign in and create the empty repository yourself.

## 1. Create the repository

1. Sign in to GitHub.
2. Select **New repository**.
3. Repository name: `azure-databricks-metadata-driven-lakehouse`.
4. Description: `AdventureWorks Azure Data Engineering portfolio using ADF, ADLS Gen2, Databricks, Delta Lake, and metadata-driven ingestion.`
5. Choose **Public** if you want recruiters to view it, or **Private** while developing.
6. Do not initialize it with a README, license, or `.gitignore` because this starter already contains those files.
7. Create the repository and copy its HTTPS URL.

## 2. Push the project from your computer

Extract the ZIP, open a terminal in the extracted `azure-databricks-metadata-driven-lakehouse` folder, and run:

```bash
git init
git add .
git status
git commit -m "Initial Azure data engineering portfolio"
git branch -M main
git remote add origin https://github.com/YOUR-GITHUB-USERNAME/azure-databricks-metadata-driven-lakehouse.git
git push -u origin main
```

Replace `YOUR-GITHUB-USERNAME` with your GitHub username. If Git is not installed, install Git first. GitHub may ask you to authenticate through a browser or credential manager; use GitHub's supported authentication flow, not a password pasted into the command.

### If you use GitHub's website instead of Git

1. Open the empty repository.
2. Choose **Add file → Upload files**.
3. Upload the extracted project contents (the files and folders inside the project folder, not the ZIP itself).
4. Commit the files to `main`.

Git is recommended because it preserves the folder structure and supports future commits and branches more cleanly.

## 3. Verify the first push

After pushing, verify that the repository shows:
- `README.md` with the architecture diagram.
- `docs/` with implementation and deployment notes.
- `adf/`, `sql/`, `databricks/`, and `config/`.
- `.github/workflows/ci.yml`.
- `portfolio-site/index.html`.

Open the **Actions** tab. The `portfolio-ci` workflow should run on the push. Fix any reported errors before treating the repository as validated.

## 4. Configure GitHub Pages (optional)

This repository includes a simple static showcase at `portfolio-site/index.html`. To publish it:

1. Open **Settings → Pages**.
2. Under **Build and deployment**, choose **GitHub Actions** as the source.
3. Add a Pages workflow that publishes `portfolio-site/` (see `.github/workflows/pages.yml` if included in your version).
4. Confirm the deployment succeeds in the Actions tab, then open the published URL shown under Pages.

Do not add secrets to the static website. GitHub Pages is public hosting; all files it publishes are visible to visitors.

## 5. Make safe updates

For each update:

```bash
git status
git add README.md docs databricks sql adf config portfolio-site
git diff --cached
git commit -m "Describe the change"
git push
```

Review staged changes before committing. Never commit `.env`, credentials, access keys, SAS tokens, production data, or unredacted logs. If a secret is committed, removing it in a later commit is not enough: revoke/rotate the secret and follow GitHub's secret-removal guidance.

## 6. Recommended repository settings

- Add a short repository description and topics: `azure-data-engineering`, `azure-data-factory`, `databricks`, `pyspark`, `delta-lake`, `adls-gen2`, `medallion-architecture`.
- Add a clear README and architecture diagram.
- Enable branch protection for `main` when you begin collaborating.
- Use pull requests for meaningful changes.
- Keep example configuration sanitized.
- Add screenshots only after successful runs, with credentials and sensitive data removed.
