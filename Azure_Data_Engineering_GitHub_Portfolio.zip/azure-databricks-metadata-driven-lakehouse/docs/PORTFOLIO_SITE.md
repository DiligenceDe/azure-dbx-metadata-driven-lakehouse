# Portfolio website

A lightweight responsive project showcase is provided in `portfolio-site/`.

## Local preview

Open `portfolio-site/index.html` in a browser. The page uses only static HTML and CSS.

## Publish with GitHub Pages

1. Replace `YOUR-GITHUB-USERNAME` in `portfolio-site/index.html` with your actual GitHub username.
2. Push the repository to GitHub.
3. Open the repository's **Settings → Pages** and select **GitHub Actions** as the build/deployment source.
4. The `.github/workflows/pages.yml` workflow packages `portfolio-site/` and deploys it when files in that directory change, or when manually triggered from Actions.
5. Open the Pages URL shown in the workflow deployment summary.

The site is public if the repository/Pages settings make it public. Do not place credentials, internal URLs, or private data in the site. The project metrics and descriptions are illustrative until replaced with verified evidence.
