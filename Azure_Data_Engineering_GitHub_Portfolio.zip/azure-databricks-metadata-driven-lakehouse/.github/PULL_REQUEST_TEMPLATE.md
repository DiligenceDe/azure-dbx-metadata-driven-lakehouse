## Summary

Describe what changed and why.

## Validation
- [ ] Python syntax and JSON checks pass
- [ ] Relevant tests pass
- [ ] Azure-specific behavior tested (if applicable)
- [ ] Untested assumptions are documented

## Security
- [ ] No secrets, credentials, production data, or unredacted logs included
- [ ] Example configuration contains placeholders only

## Evidence
Add sanitized screenshots, test output, or run evidence where relevant.
