# AdventureWorks Enterprise Lakehouse

**Azure Data Engineering Portfolio Project** · SQL Server · Azure Data Factory · ADLS Gen2 · Azure Databricks · PySpark · Delta Lake · GitHub Actions

> **Project status:** Portfolio starter / implementation blueprint. The included code and documentation are examples to adapt and validate in your Azure environment. No Azure deployment is claimed by this repository.

A practical reference project showing how to ingest AdventureWorks data using a metadata-driven ADF pipeline, land source extracts in ADLS Gen2, transform data through Bronze/Silver/Gold Delta Lake layers, apply data quality checks, and validate source code with GitHub Actions.

## What this project demonstrates

- Metadata-driven ingestion instead of one hard-coded pipeline per table.
- SQL Server → ADF → ADLS Gen2 → Databricks flow.
- Medallion Architecture: raw landing, Bronze, Silver, and Gold.
- PySpark transformation patterns and reusable data-quality helpers.
- SQL metadata tables and example configuration.
- Git-based collaboration and automated Python/JSON validation.
- Security-first configuration: no secrets committed to source control.

## Architecture

```mermaid
flowchart LR
    SQL[(SQL Server<br/>AdventureWorks)] --> LOOKUP[ADF Lookup<br/>active metadata]
    META[(Control DB<br/>source_config<br/>table_config)] --> LOOKUP
    LOOKUP --> LOOP[ForEach table]
    LOOP --> COPY[Copy Activity]
    COPY --> LAND[(ADLS Gen2<br/>raw landing / Parquet)]
    LAND --> BRONZE[Databricks Bronze<br/>Delta]
    BRONZE --> SILVER[Silver<br/>standardize + DQ]
    SILVER --> GOLD[Gold<br/>dimensions + fact]
    GOLD --> BI[Analytics / BI]
    GH[GitHub Actions<br/>code + config checks] -. validates .-> CODE[Repository source]
```

### Data layers

| Layer | Purpose | Example output |
|---|---|---|
| Raw landing | Source extracts, organized by source/table/run | Parquet files |
| Bronze | Source-aligned Delta data with ingestion metadata | `bronze.sales_customer` |
| Silver | Cleaned, standardized, deduplicated data | `silver.customer` |
| Gold | Business-ready dimensional model | `gold.dim_customer`, `gold.dim_product`, `gold.fact_sales` |

## Repository map

```text
.
├── .github/workflows/       # CI checks; optional Pages publishing workflow
├── adf/                     # ADF pipeline design and dynamic expressions
├── config/                  # Sanitized example configuration only
├── databricks/
│   ├── common/              # Reusable data-quality helpers
│   ├── bronze/              # Landing-to-Bronze example
│   ├── silver/              # Silver cleaning example
│   └── gold/                # Gold model example
├── docs/                    # HLD, metadata design, deployment and GitHub setup
├── portfolio-site/          # Lightweight responsive project showcase website
├── sql/metadata/            # Metadata table DDL and example seed data
└── tests/                   # Lightweight repository checks
```

## Quick start

1. Review `docs/high-level-design.md`, `docs/metadata-framework.md`, and `docs/deployment-guide.md`.
2. Confirm your AdventureWorks version and validate all schema/table names in `sql/metadata/002_seed_example_config.sql`.
3. Run `sql/metadata/001_create_metadata_tables.sql` in a dedicated SQL Server control database after review.
4. Configure ADF linked services for the source database, metadata database, and ADLS Gen2. Use managed identity or Azure Key Vault where supported.
5. Implement the Lookup → ForEach → Copy flow using `adf/pipeline-design.md` and test with one small table first.
6. Run the Databricks examples only after adapting storage paths, schemas, runtime, permissions, and source columns.
7. Validate full-load reruns, incremental watermarks, duplicate handling, failure logging, and restart behavior before scaling to more tables.
8. Add sanitized screenshots and real run evidence after successfully executing your own deployment.

## Run local checks

Requirements: Python 3.11+.

```bash
python -m json.tool config/source_config.example.json
python -m json.tool config/table_config.example.json
python -m compileall -q databricks tests
python -m unittest discover -s tests -v
```

GitHub Actions runs Python syntax and JSON validation on pushes and pull requests to `main`.

## Run the portfolio website locally

The lightweight showcase site is plain HTML/CSS and does not require a build tool. Open `portfolio-site/index.html` in a browser. Update the GitHub and LinkedIn URLs in the HTML before publishing. All dashboard values on the site are explicitly illustrative; replace them only with verified project results.

## Security checklist

- Never commit passwords, tokens, SAS URLs, access keys, private keys, `.env` files, or connection strings.
- Use `.env.example` only for variable names and placeholder values.
- Prefer managed identity and Key Vault for Azure resources where supported.
- Use least-privilege permissions for SQL Server, ADLS, ADF, and Databricks.
- Keep real customer, healthcare, or production data out of this portfolio.
- Review `git diff` and scan files before every push.

## Validation and limitations

The starter repository has been checked for Python syntax and JSON validity. Those checks **do not** prove that Azure SQL scripts, ADF expressions, storage permissions, Delta operations, source schemas, or end-to-end orchestration work in a particular subscription. The Azure pipeline and Databricks examples have not been deployed or runtime-tested here. Treat them as implementation examples until you validate them in your environment.

## Next milestones

- [ ] Create the GitHub repository and push this starter project.
- [ ] Implement and test ADF ingestion for 2–3 source tables.
- [ ] Validate Bronze writes and idempotent reruns.
- [ ] Add Silver data quality metrics and quarantine behavior.
- [ ] Validate Gold dimensions and fact against actual AdventureWorks columns.
- [ ] Add run logging, retries, alerting, and incremental loading.
- [ ] Add sanitized screenshots and actual run evidence.
- [ ] Configure GitHub Pages for the portfolio site if desired.

## License

This project is provided under the MIT License; see `LICENSE`. Validate any third-party datasets, screenshots, or assets you add before publishing them.
